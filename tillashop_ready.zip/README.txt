Tillashop — Website tĩnh (Catalog + Giỏ hàng)
============================================
Cách dùng nhanh:
1) Mở file index.html để xem thử trên máy.
2) Mở products.json, sửa / thêm sản phẩm (id, name, brand, cat, subcat, price, salePrice, img,...).
   - Nếu có giảm giá: để thêm salePrice (giá mới) => web tự gạch giá cũ và hiện % giảm.
   - Nếu có quà tặng khi mua combo: thêm giftName, giftOldPrice, giftImg => hiển thị quà 0₫ và gạch giá cũ.
3) Deploy miễn phí bằng Netlify (kéo-thả thư mục này vào https://app.netlify.com/drop).
4) Chia sẻ link *.netlify.app cho khách xem mẫu & giá, đặt hàng (giỏ hàng tĩnh).

Thông tin hiển thị:
- Logo chữ Tillashop (chữ nghiêng, chuyển màu xanh da trời → tím)
- Địa chỉ: Tổ dân phố Tân Hùng, phường Trần Lãm, tỉnh Hưng Yên
- SĐT: 0966597119 (có nút gọi nhanh)
- Chat: Zalo + Messenger

Chúc bán đắt hàng! 💖
